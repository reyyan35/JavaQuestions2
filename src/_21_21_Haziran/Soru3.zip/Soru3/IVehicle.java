package _21_21_Haziran.Soru3;
public interface IVehicle {
    int changeGear(int vites);
    int speedUp(int hiz);
    int applyBrakes(int fren);}