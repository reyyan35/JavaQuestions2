package _21_21_Haziran.Soru3;

public class Car extends Bicycle implements IVehicle{
    public Car(int speed, int gear) {
        super(speed, gear);
    }
}
